create your own tables please......









create table EMS_172306
(
  ProductId int  identity (1,1) primary key,
  ProductName varchar(50),
  Descript varchar(1000),
  Price int, 
);

select * from EMS_172306










CREATE PROCEDURE DisplayEMS_172306
	
AS
begin
	SELECT * from EMS_172306
END







CREATE PROCEDURE EMS_SP_172306
	(
	@ProductName varchar(50),
	@Descript varchar(1000),
	@Price int,
	@ProductId int output)
AS
	insert into EMS_172306 
	values (@ProductName, @Descript,@Price)
	set @ProductId=SCOPE_IDENTITY()
return 0
exec EMS_SP_172306


