﻿using EMSDAL;
using EMSEntity;
using EMSException;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EMSBLL
{
    public class ProductBLL
    {

        StringBuilder sb = new StringBuilder();
        private bool ValidateProduct(ProductEntity pro)
        {


            bool IsValidProduct = true;

            if (!Regex.Match(pro.ProductName, @"^[A-Z][a-z]*$").Success)
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "Product Name should contain Characters and must begin with a capital letter!");
            }
            if (!(Regex.IsMatch(pro.UnitPrice.ToString(), @"[0-9]$")))
            {
                IsValidProduct = false;
                sb.Append(Environment.NewLine + "Product Price must contain digits only");
            }
            if (pro.UnitPrice.ToString().Equals(string.Empty))
            {
                IsValidProduct = false;
                sb.Append("Product Price cannot be blank " + Environment.NewLine);

            }

            return IsValidProduct;
        }
        public DataTable DisplayProductBal()
        {
            try
            {
                ProductDAL sd = new ProductDAL();
                DataTable dtProduct = sd.DisplayProductDal();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new ProductException("No Student Available");
                }
                return dtProduct;
            }
            catch (ProductException se)
            { throw se; }
            catch (SqlException ex)
            { throw ex; }
            catch (Exception e)
            { throw e; }
        }
        public int AddProductBAL(ProductEntity pobj)
        {
            try
            {
                int pid = 0;
                ProductDAL pd = new ProductDAL();
                if (ValidateProduct(pobj))
                {
                    pid = pd.AddProductDal(pobj);
                }
                else
                    throw new ProductException(sb.ToString());

                return pid;
            }
            catch (ProductException)
            {
                throw;
            }
        }
    }
}
